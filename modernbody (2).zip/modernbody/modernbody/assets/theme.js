// =============================================
// MODERN BODY — THEME.JS
// =============================================

document.addEventListener('DOMContentLoaded', function () {

  // ── MOBILE NAV TOGGLE ──
  const navToggle = document.getElementById('navToggle');
  const mainNav = document.getElementById('mainNav');

  if (navToggle && mainNav) {
    navToggle.addEventListener('click', function () {
      const isOpen = mainNav.classList.toggle('open');
      navToggle.classList.toggle('active');
      navToggle.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
      navToggle.setAttribute('aria-expanded', isOpen ? 'true' : 'false');
      document.body.style.overflow = isOpen ? 'hidden' : '';
    });

    // Close menu on Escape key
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mainNav.classList.contains('open')) {
        mainNav.classList.remove('open');
        navToggle.classList.remove('active');
        navToggle.setAttribute('aria-label', 'Open menu');
        navToggle.setAttribute('aria-expanded', 'false');
        document.body.style.overflow = '';
        navToggle.focus();
      }
    });

    // Close menu on link click
    mainNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', function () {
        if (mainNav.classList.contains('open')) {
          mainNav.classList.remove('open');
          navToggle.classList.remove('active');
          navToggle.setAttribute('aria-label', 'Open menu');
          navToggle.setAttribute('aria-expanded', 'false');
          document.body.style.overflow = '';
        }
      });
    });
  }

  // ── STICKY HEADER SHADOW (THROTTLED) ──
  const header = document.querySelector('.site-header');
  let scrollTimeout;
  function updateHeaderShadow() {
    if (window.scrollY > 10) {
      header.style.boxShadow = '0 4px 20px rgba(0,0,0,0.1)';
    } else {
      header.style.boxShadow = '0 2px 12px rgba(0,0,0,0.04)';
    }
  }

  window.addEventListener('scroll', function () {
    if (scrollTimeout) clearTimeout(scrollTimeout);
    scrollTimeout = setTimeout(updateHeaderShadow, 16); // ~60fps throttle
  }, { passive: true });

  // ── PRODUCT IMAGE GALLERY ──
  const thumbs = document.querySelectorAll('.product-thumb');
  const mainImage = document.querySelector('.product-main-image img');

  thumbs.forEach(function (thumb) {
    thumb.addEventListener('click', function () {
      thumbs.forEach(t => t.classList.remove('active'));
      thumb.classList.add('active');
      if (mainImage) {
        // Use data-src (800x800) not the thumbnail img src (150x150)
        mainImage.src = thumb.dataset.src || thumb.querySelector('img').src;
      }
    });
  });

  // ── SIZE SELECTOR ──
  const sizeBtns = document.querySelectorAll('.size-btn');
  sizeBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      sizeBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
    });
  });

  // ── SCROLL REVEAL ANIMATION ──
  const revealEls = document.querySelectorAll(
    '.product-card, .category-card, .testimonial-card, .trust-item'
  );

  // Check if prefers-reduced-motion to respect accessibility
  const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  const observer = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  revealEls.forEach(function (el) {
    if (!prefersReducedMotion) {
      el.style.opacity = '0';
      el.style.transform = 'translateY(20px)';
      el.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    }
    observer.observe(el);
  });

  // ── ANNOUNCEMENT BAR CLOSE ──
  const announcementBar = document.querySelector('.announcement-bar');
  if (announcementBar) {
    announcementBar.addEventListener('click', function () {
      announcementBar.style.display = 'none';
    });
  }

  // ── CART COUNT UPDATE ──
  function updateCartCount() {
    fetch('/cart.js', { cache: 'no-store' })
      .then(res => res.json())
      .then(data => {
        const count = document.querySelector('.cart-count');
        if (count) {
          count.textContent = data.item_count;
          count.style.display = data.item_count > 0 ? 'flex' : 'none';
        }
      })
      .catch(err => console.error('Failed to update cart:', err));
  }
  updateCartCount();

  // ── PERFORMANCE: LAZY LOAD IMAGES ──
  if ('IntersectionObserver' in window) {
    const images = document.querySelectorAll('img:not([loading="eager"])');
    images.forEach(img => {
      if (!img.src && img.dataset.src) {
        const observer = new IntersectionObserver((entries, observer) => {
          entries.forEach(entry => {
            if (entry.isIntersecting) {
              const img = entry.target;
              img.src = img.dataset.src;
              img.removeAttribute('data-src');
              observer.unobserve(img);
            }
          });
        });
        observer.observe(img);
      }
    });
  }

  // ── MOBILE DROPDOWN ACCESSIBILITY ──
  // Make dropdowns keyboard accessible on mobile
  const dropdownTriggers = document.querySelectorAll('.has-dropdown > a');
  dropdownTriggers.forEach(trigger => {
    trigger.addEventListener('keydown', function (e) {
      if (e.key === 'Enter' || e.key === ' ') {
        e.preventDefault();
        const dropdown = this.nextElementSibling;
        if (dropdown && dropdown.classList.contains('dropdown')) {
          dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
        }
      }
    });
  });

});